

-- Add a server script
clientscript_script 'client.lua'