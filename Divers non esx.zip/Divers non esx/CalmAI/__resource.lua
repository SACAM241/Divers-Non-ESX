resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'


files {
	'events.meta',
	'relationships.dat'
}

data_file 'FIVEM_LOVES_YOU_4B38E96CC036038F' 'events.meta'

server_script 'server.lua'
client_script 'client.lua'