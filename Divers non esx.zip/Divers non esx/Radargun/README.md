# Radargun
Radargun for FiveM

- **Press Y to open**
- **Press E to freeze Measurement**

You can change this in the Config.lua :)


*Full Credits to*
- **#Brock70 for the Original Script (https://forum.fivem.net/t/release-police-alpr/61227)**
- **#Chip_W_Gaming for giving me access to reupload his Script with some changes that i made :)**
- **#Scaarus for the beautiful radargun (https://www.lcpdfr.com/files/file/18506-prolaser-4-radar-gun/)**


*Picture*
- **https://gyazo.com/fb96e33c8721640bb44af479b9f1c0d7**
