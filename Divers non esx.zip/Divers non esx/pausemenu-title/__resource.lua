client_script "server_name.lua"
