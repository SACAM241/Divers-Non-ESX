--[[
----------------------------------------------------------------------------
____________________________________________________________________________
                  AUTHOR : Anthony Roe
                  Disable the spawning of NPC cops
                  Désactive le spawn des PNJ flics
____________________________________________________________________________
---------------------------------------------------------------------------
]]--

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local myCoords = GetEntityCoords(GetPlayerPed(-1))
        ClearAreaOfCops(myCoords.x, myCoords.y, myCoords.z, 100.0, 0)
    end
end)

Citizen.CreateThread(function()
	for i = 1, 12 do
		Citizen.InvokeNative(0xDC0F817884CDD856, i, false)
	end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(3000)
       
        if GetPlayerWantedLevel(PlayerId()) ~= 0 then
            SetPlayerWantedLevel(PlayerId(), 0, false)
            SetPlayerWantedLevelNow(PlayerId(), false)
        end
    end
end)

---------------------------------
--------- ikNox#6088 ------------
---------------------------------