

client_script {
	'deletearmevehiculeclient.lua',
	'NoDrivingCopCar.lua',
	'NoMoreCopNPC.lua',
	'NoMoreWeaponsOnNPC.lua',
	'NoWeaponReward.lua',
	'passager.lua',
	'DamageReducer.lua'
}

server_script 'deletearmevehiculeserver.lua'

---------------------------------
--- Copyright by ikNox#6088 ---
---------------------------------