----------------------------------------------------------------
-- Copyright © 2019 by Guy Shefer
-- Made By: Guy293
-- GitHub: https://github.com/Guy293
-- Fivem Forum: https://forum.fivem.net/u/guy293/
----------------------------------------------------------------

resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

description 'Voice Controller'

version '1.1.0'

client_scripts {
	'client.lua'
}
