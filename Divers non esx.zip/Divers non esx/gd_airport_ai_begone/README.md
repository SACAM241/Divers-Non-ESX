# gd_airport_ai_begone
Disables certain scenarios and also removes certain cargens from the San Andreas airports and airfield.

# What gets disabled?
The following main elements are removed from the airports:
 - Jets landing and taking off at LSIA
 - Shamals and Luxors taxiing around LSIA
 - Lazers and Titans taxiing and taking off at Zancudo
 - Dusters landing on Grapeseed Airfield
 - Small planes landing and taking off at Sandy Shores Airfield
 - Various plane and vehicle spawns around all the airport surfaces
