# SCRIPT ATM MODIFIER

Script modifier par moi même avec une interface RP de la BNP Paribas

# Support : https://discord.gg/FranceLife


[PRE REQUIS]

es_extended => https://github.com/ESX-Org/es_extended

--

Credits: Script Created By: @onlyserenity(amjedcha)

