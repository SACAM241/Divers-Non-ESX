Config              = {}
Config.DrawDistance = 100.0
Config.ZoneSize     = {x = 1.0, y = 1.5, z = 1.0}
Config.MarkerColor  = {r = 100, g = 100, b = 204}
Config.MarkerType   = 27
Config.Locale = 'fr'

Config.Zones = {
    {x = 463.8985, y = -998.0825, z = 23.95}
}
-- by belford