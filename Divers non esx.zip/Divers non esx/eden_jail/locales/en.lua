Locales['en'] = {

	['access_jail_center'] = 'Press ~INPUT_PICKUP~ to take your ~b~outfit~s~.',
	['jail_center'] = 'Prisoner cloakroom',
	['jail_wear'] = 'Prisoner outfit',
	['citizen_wear'] = 'Civilian outfit',
}
