Locales['fr'] = {

	['access_jail_center'] = 'appuyez sur ~INPUT_PICKUP~ pour prendre votre ~b~tenue~s~.',
	['jail_center'] = 'Tenue prisonnier',
	['jail_wear'] = 'Tenue de prisonnier',
	['citizen_wear'] = 'Tenue Civile',
}
