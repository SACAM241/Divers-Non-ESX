# eden_jail
FXServer EDEN JAIL

[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
```
git clone https://github.com/ESX-PUBLIC/eden_jail eden_jail
```
3) Add this in your server.cfg :

```
start eden_jail
```
